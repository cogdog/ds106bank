<p>It got a bit much to update this information. Please see <a href="https://github.com/cogdog/ds106bank#assignment-bank-theme-options" target="_blank">the documentation on configuring the DS106 Assignment Bank options hosted in GitHub</a>.</p>

<p>For complete setup documentation that includes suggestions for setup, plugins, <a href="https://github.com/cogdog/ds106bank">see the theme repository on GitHub</a>. That is also <a href="https://github.com/cogdog/ds106bank/issues">a good place to ask question or toss accolades</a>.</p>



